/**
 * @param {*} initialValue 初始值
 * @param {Array} sequence 由普通函数或 Promise 函数组成的数组
 * @return {Promise} 
 */


const pipeline = (initialValue, sequence) => {
    // TODO: 待补充代码
    
};



// 检测需要，请勿删除
try {
    module.exports = { pipeline };
} catch { }
